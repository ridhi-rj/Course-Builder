import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ModuleWrapper, ModuleHeader, ModuleTitle, Button, ResourceList, ResourceItem, ResourceLink, Input } from '../styles';

const Module = ({ module, renameModule, deleteModule, addResource }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [newTitle, setNewTitle] = useState(module.title);
  const [resourceLink, setResourceLink] = useState('');
  const [resourceType, setResourceType] = useState('link');

  const handleRename = () => {
    renameModule(module.id, newTitle);
    setIsEditing(false);
  };

  const handleAddResource = () => {
    if (resourceLink.trim()) {
      addResource(module.id, { id: uuidv4(), link: resourceLink, type: resourceType });
      setResourceLink('');
    }
  };

  return (
    <ModuleWrapper>
      <ModuleHeader>
        {isEditing ? (
          <>
            <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} />
            <Button onClick={handleRename}>Save</Button>
          </>
        ) : (
          <>
            <ModuleTitle>{module.title}</ModuleTitle>
            <Button onClick={() => setIsEditing(true)}>Edit</Button>
          </>
        )}
        <Button onClick={() => deleteModule(module.id)}>Delete</Button>
      </ModuleHeader>
      <div>
        <Input value={resourceLink} onChange={(e) => setResourceLink(e.target.value)} placeholder="Add resource link" />
        <select value={resourceType} onChange={(e) => setResourceType(e.target.value)}>
          <option value="link">Link</option>
          <option value="image">Image</option>
          <option value="pdf">PDF</option>
        </select>
        <Button onClick={handleAddResource}>Add Resource</Button>
      </div>
      <ResourceList>
        {module.resources.map((resource) => (
          <ResourceItem key={resource.id}>
            <ResourceLink href={resource.link} target="_blank" rel="noopener noreferrer">
              {resource.link}
            </ResourceLink>
          </ResourceItem>
        ))}
      </ResourceList>
    </ModuleWrapper>
  );
};

export default Module;
