import React from 'react';
import Module from './Module';
import { Container, Button, Input } from '../styles';

const ModuleList = ({ modules, addModule, renameModule, deleteModule, addResource }) => {
  const [newModuleTitle, setNewModuleTitle] = React.useState('');

  const handleAddModule = () => {
    if (newModuleTitle.trim()) {
      addModule(newModuleTitle);
      setNewModuleTitle('');
    }
  };

  return (
    <Container>
      <div>
        <Input value={newModuleTitle} onChange={(e) => setNewModuleTitle(e.target.value)} placeholder="New module title" />
        <Button onClick={handleAddModule}>Add Module</Button>
      </div>
      {modules.map((module) => (
        <Module key={module.id} module={module} renameModule={renameModule} deleteModule={deleteModule} addResource={addResource} />
      ))}
    </Container>
  );
};

export default ModuleList;
