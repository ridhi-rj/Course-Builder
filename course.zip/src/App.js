// App.js
import React from 'react';
import { v4 as uuidv4 } from 'uuid';
import ModuleList from './components/ModuleList';
import useLocalStorage from './hooks/useLocalStorage';
import ErrorBoundary from './components/ErrorBoundary';

function App() {
  const [modules, setModules] = useLocalStorage('modules', []);

  const addModule = (title) => {
    setModules((prevModules) => {
      const newModule = { id: uuidv4(), title, resources: [] };
      return [...prevModules, newModule];
    });
  };

  const renameModule = (id, newTitle) => {
    const updatedModules = modules.map((module) => 
      module.id === id ? { ...module, title: newTitle } : module
    );
    setModules(updatedModules);
  };

  const deleteModule = (id) => {
    const updatedModules = modules.filter((module) => module.id !== id);
    setModules(updatedModules);
  };

  const addResource = (moduleId, resource) => {
    const updatedModules = modules.map((module) => 
      module.id === moduleId ? { ...module, resources: [...module.resources, resource] } : module
    );
    setModules(updatedModules);
  };

  return (
    <ErrorBoundary>
      <div className="App">
        <ModuleList 
          modules={modules}
          addModule={addModule}
          renameModule={renameModule}
          deleteModule={deleteModule}
          addResource={addResource}
        />
      </div>
    </ErrorBoundary>
  );
}

export default App;
