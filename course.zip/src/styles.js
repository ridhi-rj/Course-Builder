import styled from 'styled-components';

export const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
`;

export const ModuleWrapper = styled.div`
  border: 1px solid #ccc;
  margin-bottom: 20px;
  padding: 20px;
  border-radius: 5px;
`;

export const ModuleHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

export const ModuleTitle = styled.h2`
  margin: 0;
`;

export const Button = styled.button`
  background: #007bff;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  &:hover {
    background: #0056b3;
  }
`;

export const Input = styled.input`
  padding: 10px;
  margin-right: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

export const ResourceList = styled.ul`
  list-style: none;
  padding: 0;
`;

export const ResourceItem = styled.li`
  padding: 5px 0;
`;

export const ResourceLink = styled.a`
  color: #007bff;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`;
